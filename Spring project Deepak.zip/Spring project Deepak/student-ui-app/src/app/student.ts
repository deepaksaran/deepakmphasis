export class Student {
    id: number;
    name: string;
    salary: number;
    designation: string;
    email: string;
    addr: string;
}

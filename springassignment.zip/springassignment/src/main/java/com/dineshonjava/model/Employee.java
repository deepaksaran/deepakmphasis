package com.dineshonjava.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

 
@Entity
@Table(name="Employee")
public class Employee implements Serializable{

	 
	
	@Id
	 
	@Column(name="empname")
	private String empName;
	
	@Column(name="empaddress")
	private String empAddress;
	
	@Column(name="salary")
	private Long salary;
	
	@Column(name="empAge")
	private Integer empAge;
	
	@Column(name="empEmail")
	private String empEmail;
	
	@Column(name="empBalance")
	private String empBalance;
	
	@Column(name="empPhoneno")
	private String empPhoneno;


	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpAddress() {
		return empAddress;
	}

	public void setEmpAddress(String empAddress) {
		this.empAddress = empAddress;
	}

	public Long getSalary() {
		return salary;
	}

	public void setSalary(Long salary) {
		this.salary = salary;
	}

	public Integer getEmpAge() {
		return empAge;
	}

	public void setEmpAge(Integer empAge) {
		this.empAge = empAge;
	}
	public String getEmpEmail() {
		return empEmail;
	}

	public void setEmpEmail(String empEmail) {
		this.empEmail = empEmail;
	}
	public String getEmpBalance() {
		return empBalance;
	}

	public void setEmpBalance(String empBalance) {
		this.empBalance = empBalance;
	}
	public String getEmpPhoneno() {
		return empPhoneno;
	}

	public void setEmpPhoneno(String empPhoneno) {
		this.empPhoneno = empPhoneno;
	}
}
